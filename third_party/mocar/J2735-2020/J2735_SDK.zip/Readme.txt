SDK based on J2735
include : contain the ".h" files for supported api functions and data structure definitions ;
lib: contain the ".so" library file needed for develop;
